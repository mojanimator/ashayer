<?php $__env->startSection('title'); ?>
    پنل کاربر
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
    <section class=" container-fluid  mt-4 mx-2" id="app">

        
        <search-box schools-link="<?php echo e(route('school.search')); ?>"
                    hoozes-link="<?php echo e(route('school.hoozes')); ?>"></search-box>

        <pagination></pagination>
        <school-cards user="<?php echo e(auth()->user()); ?>"></school-cards>

        <div class="row  justify-content-center">
            <div class="no-result text-center py-4 text-danger  hide">نتیــجه ای یافت نشد</div>
            <div class="loading-page center-block  "></div>
        </div>
        

        
        
        
        
        
        
        
        
        
        
        
        
    </section>


<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>

    
    
    
    
    
    
    
    
    
    
    
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\_laravelProjects\ashayer\resources\views/schools.blade.php ENDPATH**/ ?>