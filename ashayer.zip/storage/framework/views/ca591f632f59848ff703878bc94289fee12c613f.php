<?php $__env->startSection('title'); ?>
    مدارس
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <school-cards schools-link="<?php echo e(route('madrese.all')); ?>"></school-cards>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\_laravelProjects\ashayer\resources\views/madrese/view.blade.php ENDPATH**/ ?>