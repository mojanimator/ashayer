<?php $__env->startSection('content'); ?>
    <!-- Preloader Start -->
    <div id="preloader">
        <div class="colorlib-load"></div>
    </div>

    <!-- ***** Header Area Start ***** -->
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    <!-- ***** Header Area End ***** -->

    <!-- ***** Wellcome Area Start ***** -->
    <section class="wellcome-area clearfix" id="home">
        <div class="container-fluid h-100">
            <div class="row h-100 align-items-center">
                <img src="/img/ashayer_bg.png" alt="">
                <div class="col-12 col-md">
                    <div class="wellcome-heading">
                        <h3> سامانه مدارس عشایر کرمان </h3>

                        <h2>سامانه مدارس عشایر کرمان</h2>
                        <p>مدیریت و سازمان دهی مدارس عشایر کرمان</p>
                    </div>
                    <div class="get-start-area">
                        <!-- Form Start -->
                        <form action="#" method="post" class="form-inline">
                            
                            <?php if(auth()->guest()): ?>
                                <a class="m-btn nav-link text-center" href="<?php echo e(url('login')); ?>">ورود</a>
                                <a class="m-btn nav-link text-center" href="<?php echo e(url('register')); ?>">ثبت نام</a>
                            <?php else: ?>
                                <a class="m-btn nav-link text-center" href="<?php echo e(url('login')); ?>">حساب کاربری</a>
                                <a class="m-btn nav-link text-center" href="<?php echo e(url('register')); ?>">خروج</a>
                            <?php endif; ?>
                        </form>
                        <!-- Form End -->
                    </div>
                </div>
            </div>
        </div>
        <!-- Welcome thumb -->
        
        
        
    </section>
    <!-- ***** Wellcome Area End ***** -->

    <!-- ***** Awesome Features Start ***** -->
    <section class="features-area  bg-white section_padding_0_50 clearfix" id="features">
        <div class="container  ">
            <div class="row">
                <div class="col-12">
                    <!-- Heading Text -->
                    <div class="section-heading text-center">
                        <h2>امکانات</h2>
                        <div class="line-shape"></div>
                    </div>
                </div>
            </div>

            <div class="row m-features">
                <!-- Single Feature Start -->
                <div class="col-lg-2"></div>
                <div class="col-12 col-sm-6 col-lg-4">

                    <div class="m-card">

                    </div>

                </div>
                <!-- Single Feature Start -->
                <div class="col-12 col-sm-6 col-lg-4">

                </div>


            </div>

        </div>
    </section>
    <!-- ***** Awesome Features End ***** -->

    <section class="madrese-num">
        <div id="counter">
            <div class="counter-value" data-count="300">0</div>
            <div class="counter-value" data-count="400">100</div>
            <div class="counter-value" data-count="1500">200</div>
        </div>
    </section>

    <!-- ***** Video Area Start ***** -->
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    <!-- ***** Video Area End ***** -->

    <!-- ***** Cool Facts Area Start ***** -->
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    <!-- ***** Cool Facts Area End ***** -->

    <!-- ***** App Screenshots Area Start ***** -->
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    <!-- ***** App Screenshots Area End *****====== -->

    <!-- ***** Pricing Plane Area Start *****==== -->
    
    
    
    
    
    
    
    
    
    
    

    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    <!-- ***** Pricing Plane Area End ***** -->

    <!-- ***** Client Feedback Area Start ***** -->
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    <!-- ***** Client Feedback Area End ***** -->

    <!-- ***** CTA Area Start ***** -->
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    <!-- ***** CTA Area End ***** -->

    <!-- ***** Our Team Area Start ***** -->
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    <!-- ***** Our Team Area End ***** -->

    <!-- ***** Contact Us Area Start ***** -->
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    <!-- ***** Contact Us Area End ***** -->




<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
    <script src="js/home.js"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\_laravelProjects\ashayer\resources\views/layouts/home.blade.php ENDPATH**/ ?>