<?php $__env->startSection('title'); ?>
    پنل کاربر
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
    <section class=" container-fluid  mt-4 mx-2" id="app">

        


        <school-create user="<?php echo e(auth()->user()); ?>" schools-link="<?php echo e(route('school.dropdown')); ?>"
                       hoozes-link="<?php echo e(route('school.hoozes')); ?>"></school-create>

        <div class="row  justify-content-center">

            <div class="loading-page center-block hide "></div>
        </div>
        

        
        
        
        
        
        
        
        
        
        
        
        
    </section>


<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\_laravelProjects\ashayer\resources\views/school/create.blade.php ENDPATH**/ ?>