<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Doore extends Model
{
    protected $fillable = ['name',];

    protected $table = 'dooreha';
}
